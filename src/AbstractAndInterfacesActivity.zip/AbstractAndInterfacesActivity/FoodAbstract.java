package AbstractAndInterfacesActivity;

public class FoodAbstract {
    private Double Popcorn;

    public FoodAbstract(){

    }
    public FoodAbstract(String MovieTitle, String Genre, Double Runtime, Double Popcorn){
        this.Popcorn = Popcorn;
    }
    public void setPopcorn(Double Popcorn){
        this.Popcorn = Popcorn;
    }
    public double getPopcorn(){
        return Popcorn;
    }
    @Override
    public String toString(){
        return super.toString() + String.format("Popcorn cost: %.2f", Popcorn);
    }
}
