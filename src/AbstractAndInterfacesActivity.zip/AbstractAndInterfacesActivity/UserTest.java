package AbstractAndInterfacesActivity;

public class UserTest {
    public static void main(String[] args) {
        User Buford = new User("Chicken Litle","Horror",120,"Buford","TheBuford@gmail.com","TheSkyIsFalling");
        Buford.displayDetails();
    }

}
