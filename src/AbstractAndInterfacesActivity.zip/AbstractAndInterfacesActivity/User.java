package AbstractAndInterfacesActivity;

public class User extends abstractMovie{
   public String Name;
   public String Email;
   public String Password;

    public User(){

    }
    public User(String MoveTitle, String Genre, int Runtime, String Name, String Email, String Password){
        super(MoveTitle, Genre, Runtime);
        this.Name = Name;
        this.Email = Email;
        this.Password = Password;

    }
    @Override
    public void displayDetails(){
        System.out.println(String.format("User: %s%nEmail: %s%nPassword: %s%n\nMovieTitle: %s%nGenre: %s%nRuntime: ",Name,Email,Password,MovieTitle,Genre,Runtime));

    }

}
