package AbstractAndInterfacesActivity;

public abstract class abstractMovie {
    public String MovieTitle;
    public String Genre;
    public int Runtime;

    public abstractMovie(){

    }
    public abstractMovie(String MovieTitle, String Genre, int Runtime){
        this.MovieTitle = MovieTitle;
        this.Genre = Genre;
        this.Runtime = Runtime;
    }
    public void setMovieTitle(String MovieTitle){
        this.MovieTitle = MovieTitle;
    }
    public void setGenre(String Genre){
        this.Genre = Genre;
    }
    public void setRuntime(int Runtime){
        this.Runtime = Runtime;
    }
    public String getMovieTitle(){
        return MovieTitle;
    }
    public String getGenre(){
        return Genre;
    }
    public int getRuntime(){
        return Runtime;
    }
    @Override
    public String toString(){
        return String.format("Movie Title: %s Genre: %s Year: %d",MovieTitle,Genre,Runtime);
    }
    public abstract void displayDetails();

}