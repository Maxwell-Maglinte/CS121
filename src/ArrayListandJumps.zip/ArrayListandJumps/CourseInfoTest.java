package ArrayListandJumps;

import java.util.Scanner;

public class CourseInfoTest {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        CourseInfo courseinfo = new CourseInfo();
        while(true){
            System.out.println("Enter Course or q to quit: ");
            String input = scanner.nextLine();
            if(input.equals("q")){
                System.out.println("Goodbye");
                break;
            }else{
                courseinfo.addName(input);
                System.out.println("Enter GPA: ");
                courseinfo.addGPA(Double.parseDouble(scanner.nextLine()));
                System.out.println("Enter Score: ");
                courseinfo.addScores(Integer.parseInt(scanner.nextLine()));
                System.out.println("Enter Letter Grade: ");
                courseinfo.addLetterGrade(scanner.next().charAt(0));
                scanner.nextLine();

            }
        }
        courseinfo.displayCourses();
    }
}
