package ArrayListandJumps;
import java.util.ArrayList;

public class StringArrayList {
    private ArrayList<String>names;

    public StringArrayList(){
        this.names = new ArrayList<>();
    }
    public void addName(String name){
        names.remove(name);
    }
    public void removeName(String name){
        names.remove(name);
    }
    public String getValueUsingIndex(int index) {
        return names.get(index);
    }
    public String displayWithForEachFormat(){
        StringBuilder sb = new StringBuilder();
        for(String n: names){
            sb.append(String.format("%s%n", n));
        }
        return sb.toString();
    }
    public String displayWithForLoopFormat(){
        StringBuilder sb = new StringBuilder();
        for(int i=0; i<names.size(); i++){
            sb.append(String.format("%s%n",names.get(i)));
        }
        return sb.toString();
    }
}
