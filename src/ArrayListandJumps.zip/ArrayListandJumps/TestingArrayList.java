package ArrayListandJumps;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
public class TestingArrayList {

    private StringArrayList names;

    @BeforeEach
    public void setup(){
        names = new StringArrayList();
    }
    @Test
    public void testAddString(){
        names.addName("Goro M.");
        assertEquals(1,names.sizeOfName());
    }
    @Test
    public void testRemoveString(){
        names.removeName("Goro M.");
        assertEquals(0,names.sizeOfName());
    }
    @Test
    public void testGetSize(){
        names.addName("Ethan S.");
        names.addName("Leon K.");
        names.addName("Isaac C.");
        assertEquals(3,names.sizeOfName());
    }
    @Test
    public void testGetElementAtIndex(){
        names.addName("Claire R.");
        names.addName("Varg V.");
        assertEquals("Varg V.", names.getValueUsingIndex(1));

    }
    @Test
    public void testStringValue(){
        names.addName("Goro M.");
        names.addName("Ethan S.");
        names.addName("Leon K.");
        names.addName("Isaac C.");
        names.addName("Claire R.");
        names.addName("Varg V.");
        String expected = "Goro M.\nEthan S.\nLeon K.\nIsaas C.\nClaire R.\nVarg V.";
        String actual = names.displayWithForEachFormat();
        assertEquals(expected,actual);

    }
}
