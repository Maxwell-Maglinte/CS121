package Inheritance;
//Child Class

public class Tickets extends Movie{
    private double Price;

    public Tickets(){

    }
    public Tickets(String MovieTitle, String Genre, Double Runtime){
        super(MovieTitle, Genre,Runtime);
        this.Price = Price;
    }
    public void setPrice(Double Price){
        this.Price = Price;
    }
    public double getPrice(){
        return Price;
    }

    @Override
    public String toString(){
        return super.toString() + String.format(" Price %.2f", Price);
    }
}
