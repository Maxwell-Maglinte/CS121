package Inheritance;

public class Movie {
    private String MovieTitle;
    private String Genre;
    private Double Runtime;

    public Movie(){

    }
    public Movie(String MovieTitle, String Genre, Double Runtime){
        this.MovieTitle = MovieTitle;
        this.Genre = Genre;
        this.Runtime = Runtime;
    }
    public void setMovieTitle(String MovieTitle){
        this.MovieTitle = MovieTitle;
    }
    public void setGenre(String Genre){
        this.Genre = Genre;
    }
    public void setRuntime(Double Runtime){
        this.Runtime = Runtime;
    }
    public String getMovieTitle(){
        return MovieTitle;
    }
    public String getGenre(){
        return Genre;
    }
    public Double getRuntime(){
        return Runtime;
    }
    @Override
    public String toString(){
        return String.format("Movie Title: %s Genre: %s Year: %d",MovieTitle,Genre,Runtime);
    }

}
