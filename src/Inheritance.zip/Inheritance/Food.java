package Inheritance;

public class Food extends Movie {
    private Double Popcorn;

    public Food(){

    }
    public Food(String MovieTitle, String Genre, Double Runtime, Double Popcorn){
        super(MovieTitle, Genre, Runtime);
        this.Popcorn = Popcorn;
    }
    public void setPopcorn(Double Popcorn){
        this.Popcorn = Popcorn;
    }
    public double getPopcorn(){
        return Popcorn;
    }
    @Override
    public String toString(){
        return super.toString() + String.format("Popcorn cost: %.2f", Popcorn);
    }
}
