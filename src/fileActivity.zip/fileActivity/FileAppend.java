package fileActivity;
import javax.swing.JOptionPane;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class FileAppend {
    public static void main(String[] args) throws IOException {

        FileWriter filewrite = new FileWriter("Courses.txt", true);
        PrintWriter output = new PrintWriter(filewrite);
        String Courses  = JOptionPane.showInputDialog("Enter Course Name: ");
        String Credits = JOptionPane.showInputDialog("Enter Course Credits: ");
        int Score = Integer.parseInt(JOptionPane.showInputDialog("Enter Course Score: "));

        output.printf("%s %s %s\n", "<Courses>", "<Credits>", "<Score>");

        filewrite.close();




    }
}


