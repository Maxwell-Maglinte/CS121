package fileActivity;

import java.io.FileNotFoundException;
import java.io.File;
import java.util.Scanner;

public class FileRead {
    public static void main(String[] args) throws FileNotFoundException {

        //Absolute Path
        File file = new File("C:\\Users\\thema\\IdeaProjects\\cs121");

        try {
            Scanner console = new Scanner(file);

            String header = console.nextLine();
            System.out.printf("%s",header);
            while (console.hasNextLine()) {
                String Course = console.next();
                String Credit = console.next();
                int Score = Integer.parseInt(console.next());


                System.out.printf("%s %s %s\n","<Courses>", "<Credits>", "<Score>");
            }
                while(console.hasNextLine()){
                    String Line = console.nextLine();
                System.out.println(Line);
            }
            }catch(FileNotFoundException e){e.printStackTrace();
        }
    }
}

