package fileActivity;

import javax.swing.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;

public class FileWrite {
    public static void main(String[] args) throws FileNotFoundException {


        File outputfile = new File("MyCourses.txt");

        PrintWriter output = new PrintWriter(outputfile);

        String Courses, Credits, Scores;

        output.printf("%s %s %s \n","<Courses>","<Credits>", "<Score>");


        for(int i=1; i <= 6; i++);{
            Courses = JOptionPane.showInputDialog(String.format("Enter course names %d"));
            Credits = JOptionPane.showInputDialog("Enter course credits");
            Scores = JOptionPane.showInputDialog("Enter course score");
            output.printf("%s %s %s\n", Courses, Credits, Scores);
        }
        output.close();
    }

}
