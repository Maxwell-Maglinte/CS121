package BigOActivity;

public class BigOTest {
    public static void main(String[] args) {
        BigO x = new BigO();
        x.printNSquaredTimes(5);
        x.printNTimes(3);
        x.printOnce("Mr.Kennedy");
    }
}
