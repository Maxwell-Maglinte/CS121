package BigOActivity;

public class BigO {
    public static void printOnce(String name) {
        System.out.println(name);

    }
    public static void printNTimes(int n){
        int count = 0;
        for(int i = 1; i<=n; i++){
            System.out.println("#"+(count + 1)+": " + "Where's Everyone Going,Bingo?");
            count++;
        }
        System.out.println();
    }
    public static void printNSquaredTimes(int n){
        int count = 0;
        for(int i = 1; i<= n; i++){
            for(int j = 1; j<= n; j++){
                System.out.println("#"+(count +1 ) + ": "+"Your Right Hand Comes Off?");

            }
        }
    }

}
