package ProjectOne;

import java.util.Scanner;
import java.util.Random;
public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Random random = new Random();
        BattleMain testOne = new BattleMain();
        //BattleMath(String Player1, String Player2, int Player1Health,int Player2Health,String Player1Ability,String Player2Ability,int Player1AP,int Player2AP,int Player1Speed,int Player2Speed )
        //Round Count
        System.out.println("Enter the amount of round you want to play (must be an odd number):");
        int roundcount = Integer.parseInt(input.nextLine());
        if (roundcount % 2 == 0) {
            System.out.println("Not an odd number");
            return;
        }

// Player 1
        System.out.println("Enter your Character's name Player 1:");
        testOne.setPlayer1(input.nextLine());
        System.out.println("Enter Character's Health Pool:");
        testOne.setPlayer1Health(Integer.parseInt(input.nextLine()));
        System.out.println("Enter Character's Ability:");
        testOne.setPlayer1Ability(input.nextLine());

        System.out.println("Enter Character's Ability Power:");
        testOne.setPlayer1AP(Integer.parseInt(input.nextLine()));
        System.out.println("Enter Character's Speed:");
        testOne.setPlayer1Speed(Integer.parseInt(input.nextLine()));
// Player 2
        System.out.println("Enter your Character's name Player 2:");
        testOne.setPlayer2(input.nextLine());
        System.out.println("Enter Character's Health Pool:");
        testOne.setPlayer2Health(Integer.parseInt(input.nextLine()));
        System.out.println("Enter Character's Ability:");
        testOne.setPlayer2Ability(input.nextLine());
        System.out.println("Enter Character's Ability Power:");
        testOne.setPlayer2AP(Integer.parseInt(input.nextLine()));
        System.out.println("Enter Character's Speed:");
        testOne.setPlayer2Speed(Integer.parseInt(input.nextLine()));
        // Loop that check to see if character health is at zero.
        while(testOne.getPlayer1Health() > 0 && testOne.getPlayer2Health()  > 0)
        {
            //If statement determines which player has more speed so they can attack first. As while as a randomizer
            // if speeds are equal to determine who goes first.
            if(testOne.getPlayer1Speed()  > testOne.getPlayer2Speed()) {
                testOne.StartPlayer1Attack();
            }
            else if (testOne.getPlayer1Speed() < testOne.getPlayer2Speed()){
                testOne.StartPlayer2Attack();
            }
            //for(int i=0; i<roundcount; i++)
            //Randomizer
            else{

                int rand = random.nextInt(2);
                if (rand == 1) {
                    testOne.StartPlayer1Attack();
                }else{
                    testOne.StartPlayer2Attack();
                }
            }
            // Print scores
            System.out.println("Player 1 Scored "+ testOne.getPlayer1Wins() +" Rounds");
            System.out.println("Player 2 Scored "+ testOne.getPlayer2Wins() +" Rounds");
            if (testOne.getPlayer1Wins() > testOne.getPlayer2Wins())
            {
                System.out.println("Player 1 Won");

            }
            else{
                System.out.println("Player 2 Won");
            }
        }

    }
}