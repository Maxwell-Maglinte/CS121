package ProjectOne;

public class BattleMain {
    private String Player1;
    private int Player1Health;
    private String Player1Ability; // Ability Power
    private int Player1AP;
    private int Player1Speed;
    private String Player2;
    private int Player2Health;
    private String Player2Ability;
    private int Player2AP; // Ability Power
    private int Player2Speed;
    private int  Player1Wins =0 ,  Player2Wins=0;

    // Constructor
    //Default Constructor
    public BattleMain() {

    }
    public BattleMain(String Player1, int Player1Health,  String Player1Ability, int Player1AP,  int Player1Speed) {
        this.Player1 = Player1;
        this.Player1Health = Player1Health;
        this.Player1Ability = Player1Ability;
        this.Player1AP = Player1AP;
        this.Player1Speed = Player1Speed;
    }
    public BattleMain(String Player1, String Player2, int Player1Health, int Player2Health, String Player1Ability, String Player2Ability, int Player1AP, int Player2AP, int Player1Speed, int Player2Speed) {
        this.Player1 = Player1;
        this.Player2 = Player2;
        this.Player1Health = Player1Health;
        this.Player2Health = Player2Health;
        this.Player1Ability = Player1Ability;
        this.Player2Ability = Player2Ability;
        this.Player1AP = Player1AP;
        this.Player2AP = Player2AP;
        this.Player1Speed = Player1Speed;
        this.Player2Speed = Player2Speed;
    }

    //Setters and Getters
    public String getPlayer1() {
        return Player1;
    }

    public void setPlayer1(String Player1) {
        this.Player1 = Player1;
    }

    public String getPlayer2() {
        return Player2;
    }

    public void setPlayer2(String Player2) {
        this.Player1 = Player1;
    }
    public void setPlayer2(String Player2, String message) {
        this.Player1 = Player1;
        System.out.println(message);
    }

    public int getPlayer1Health() {
        return Player1Health;
    }

    public void setPlayer1Health(int Player1Health) {
        this.Player1Health = Player1Health;
    }

    public int getPlayer2Health() {
        return Player2Health;
    }

    public void setPlayer2Health(int Player2Health) {
        this.Player2Health = Player2Health;
    }

    public String getPlayer1Ability() {
        return Player1Ability;
    }

    public String getPlayer2Ability() {
        return Player2Ability;
    }

    public void setPlayer1Ability(String Player1Ability) {
        this.Player1Ability = Player1Ability;
    }

    public void setPlayer2Ability(String Player2Ability) {
        this.Player2Ability = Player2Ability;
    }

    public int getPlayer1Wins() {
        return Player1Wins;
    }

    public int getPlayer2Wins() {
        return Player2Wins;
    }

    public void setPlayer1Wins(int Player1Wins) {
        this.Player1Wins = Player1Wins;
    }

    public void setPlayer2Wins(int Player2Wins) {
        this.Player2Wins= Player2Wins;
    }

    public int getPlayer1Speed() {
        return Player1Speed;
    }

    public int getPlayer2Speed() {
        return Player2Speed;
    }

    public void setPlayer1Speed(int Player1Speed) {
        this.Player1Speed = Player1Speed;
    }

    public void setPlayer2Speed(int Player2Speed) {
        this.Player2Speed = Player2Speed;
    }
    public int getPlayer1AP() {
        return Player1AP;
    }

    public int getPlayer2AP() {
        return Player2AP;
    }

    public void setPlayer1AP(int Player1AP) {
        this.Player1AP = Player1AP;
    }

    public void setPlayer2AP(int Player2AP) {
        this.Player2AP = Player2AP;
    }

    //Battle Dialog
    // Player 1 attacks Player 2
    void StartPlayer1Attack() {
        System.out.println("Player 1's Attack");
        Player2Health = Player2Health - Player1AP; // Subtracts health from player 2
        System.out.println(this.Player1 + " choice " + Player1Ability);
        System.out.println(this.Player1 + " attacked " + this.Player2 + " dealing " + Player1AP + " Damage." + "\n" + this.Player2 + "Has" +
                Player2Health + "remaining.");
        // If player 1 won
        if (Player2Health <= 0) {
            System.out.println("Player 1 won the round");
            Player1Wins++; // Adds 1 to round win counter
            return;
        }
        System.out.println("Player 2's Attack");
        Player1Health = Player1Health - Player2AP; // Damage dealt to player 1
        System.out.println(this.Player2 + " choice " + Player2Ability);
        System.out.println(this.Player2 + " attacked " + Player1 + " dealing " + Player2AP + " Damage." + "\n" + Player1 + "Has" +
                Player1Health + "remaining.");
        // If player 2 won
        if (Player1Health <= 0) {
            System.out.println("Player 2 won the round");
            Player2Wins++; // Adds 1 to round win counter
            return;
        }
    }

    void StartPlayer2Attack()
    {
        System.out.println("Player 2's Attack");
        Player1Health = Player1Health - Player2AP; // Damage dealt to player 1
        System.out.println(Player2 + "choice" + Player2Ability);
        System.out.println(Player2 + "attacked" + this.Player1 + "dealing" + Player2AP + "Damage." + "\n" + this.Player1 + "Has" +
                Player1Health + "remaining.");
        // If player 2 won
        if (Player1Health <= 0) {
            System.out.println("Player 2 won the round");
            Player2Wins++; // Adds 1 to round win counter
            return;
        }
        System.out.println("Player 1's Attack");
        Player2Health = Player2Health - Player1AP; // Subtracts health from player 2
        System.out.println(Player1 + "choice" + Player1Ability);
        System.out.println(Player1 + "attacked" + Player2 + "dealing" + Player1AP + "Damage." + "\n" + Player2 + "Has" +
                Player2Health + "remaining.");
        // If player 1 won
        if (Player2Health <= 0) {
            System.out.println("Player 1 won the round");
            Player1Wins++; // Adds 1 to round win counter
            return;
        }
    }

}